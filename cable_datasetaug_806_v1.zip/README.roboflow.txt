
CABLURI_v2 - v1 paper_10122020_V2
==============================

This dataset was exported via roboflow.ai on December 10, 2020 at 6:09 PM GMT

It includes 342 images.
Cables are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


