
Fabrica_init - v2 v2_Test_laptopnormal
==============================

This dataset was exported via roboflow.ai on December 11, 2020 at 12:35 PM GMT

It includes 400 images.
Pieces are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Random rotation of between -24 and +24 degrees
* Random Gaussian blur of between 0 and 2.5 pixels


